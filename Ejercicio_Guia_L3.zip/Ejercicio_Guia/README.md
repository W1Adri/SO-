Con el codigo que nos ha dejado miguel he hecho el ejercicio que luego nos ha servido para la V1
